import { Component } from '@angular/core';

@Component({
  selector: 'app-es1',
  imports: [],
  templateUrl: './es1.component.html',
  standalone: true,
  styleUrl: './es1.component.css'
})
export class Es1Component {

}
